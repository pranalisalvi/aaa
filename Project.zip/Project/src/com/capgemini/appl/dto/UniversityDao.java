package com.capgemini.appl.dto;




import java.sql.Date;
import java.util.List;

import com.capgemini.appl.dao.Application;
import com.capgemini.appl.dao.ProgramsScheduled;
import com.capgemini.appl.exception.UniversityAdmissionException;

public interface UniversityDao {
	
		public List<ProgramsScheduled> showProgramInfo(Date startdate,Date enddate) throws UniversityAdmissionException;
}
