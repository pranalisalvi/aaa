package com.capgemini.appl.dto;

public class UniversityDtoImpl  implements UniversityDto{

	public UniversityDtoImpl() {
		// TODO Auto-generated constructor stub
	}

}
